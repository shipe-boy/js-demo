(function () {

    var guid = "000000000";
    var QQmusic = function (text, pagesize) {
        new QQmusic.songmid(text, pagesize)
    };

    QQmusic.songmid = function (text, pagesize) {

        let query_URL = "https://c.y.qq.com/soso/fcgi-bin/client_search_cp?aggr=1&cr=1&flag_qc=0&p=1&n=" + pagesize + "&w=" + text;
        $.ajax({
            url: query_URL,
            dataType: "jsonp",
            type: "get"
        })
    };

    QQmusic.mid = function (e, fn) {
        let mid = {};
        for (let i = 0; i < e.length; i++) {
            mid[i] = JSON.parse('{"songmid":"' + e[i].songmid + '","albumname":"' + e[i].albumname + '","singer":{},"url":"","musicimg":"https://y.gtimg.cn/music/photo_new/T002R300x300M000'+e[i].albummid+'.jpg?max_age=2592000"}');
            for (let y = 0; y < e[i].singer.length; y++) {
                mid[i].singer[y] = e[i].singer[y].name;
                mid[i].singer.length = y+1;
            }
            mid.length = i + 1;
        }
        return QQmusic.Vkey(mid, fn);
    };

    QQmusic.Vkey = function (e, fn) {
        var obj = e, y = 0;
        for (let i = 0; i < e.length; i++) {
            var VKey = "https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?format=json205361747&platform=yqq&cid=205361747&songmid=" + e[i].songmid + "&filename=C400" + e[i].songmid + ".m4a&guid=000000000";
            $.ajax({
                url: VKey,
                dataType: "jsonp",
                type: "post",
                success: function (data) {
                    if (data.data.items[0].vkey != "" && data.data.items[0].vkey) {
                        obj[i].url = "http://113.106.207.149/amobile.music.tc.qq.com/" + data.data.items[0].filename + "?guid=" + guid + "&vkey=" + data.data.items[0].vkey + "&fromtag=0";
                    }else{
                        obj[i].url = "不存在"
                    }
                }
            });
        }
        fn(obj);
    };

    //移除事件监听
    QQmusic.removeEvents = function(target,type){
        if (window.removeEventListener){
            for (key in target){
                target[key].removeEventListener(type,function () {
                    console.log(this);
                },false)
            }
        }else{
            for (key in target){
                target[key].detachEvent("on"+type,function () {
                    console.log(this);
                })
            }
        }
    };

    window.QQmusic = QQmusic;
})();