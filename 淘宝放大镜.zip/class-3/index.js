
// 获取所有需要操作的元素
var moveBox = document.getElementsByClassName('move-box')[0];
var imgList = document.getElementsByClassName('img-list')[0];
var wrapper = document.getElementsByClassName('wrapper')[0];
var content = document.getElementsByClassName('content')[0];
var imgCover = content.getElementsByClassName('img-cover')[0];
var viewContent = document.getElementsByClassName('view')[0];

// 放大倍数
var mul = 4;
var imgW, imgH;
var contentWidth = 500;
var moveBoxWidth = contentWidth / mul;
function initMoveBox() {
    moveBox.style.width = moveBoxWidth + 'px';
    moveBox.style.height = moveBoxWidth + 'px';
}

function bindEvent() {
    imgList.onclick = function (e) {
        var target = e.target;
        var src = target.getAttribute('src');
        setImage(src);
    }
    content.onmousemove = function (e) {
        move(e);
    }
    content.onmouseleave = function (e) {
        moveBox.style.display = 'none';
        viewContent.style.display = 'none';
    }
}
// 滑块移动
function move(e) {
    // 方块可移动到的最小left值
    var minLeft = ( content.offsetWidth - imgW ) / 2;
    // 方块可移动到的最小top值
    var minTop = (content.offsetHeight - imgH) / 2;
    // 方块可移动到的最大left值
    var maxLeft = content.offsetWidth - moveBoxWidth - minLeft;
    // 方块可移动到的最大top值
    var maxTop = content.offsetHeight - moveBoxWidth - minTop;
    // 方块跟随鼠标移动的实际left，top值
    var left = e.clientX - wrapper.offsetLeft - moveBoxWidth / 2;
    var top = e.clientY - wrapper.offsetTop - moveBoxWidth / 2;
    // 当方块移动的位置小于最小的left时  将其置为最小left的大小
    // 当方块移动的位置大于最小的left时  将其置为大left的大小
    if (left < minLeft) {
        left = minLeft;
    } else if (left > maxLeft) {
        left = maxLeft;
    }
    if (top < minTop) {
        top = minTop;
    } else if(top > maxTop) {
        top = maxTop;
    }
    // 设置滑块位置
    moveBox.style.left = left + 'px';
    moveBox.style.top = top + 'px';
    moveBox.style.display = 'block';
    // 设置放大之后的图片位置
    // 放大图片的位置通过margin来定位
    // marginLeft的值为 被放大部分的left值 - 图片距离外层区域的部分（即滑块可移动到的最小left位置）
    var viewLeft = left - minLeft;
    // marginTop的值为 被放大的部分的top值 - 图片距离外层区域的部分（即滑块可移动到的最小top的位置）
    var viewTop = top - minTop;
    var viewImg = viewContent.getElementsByTagName('img')[0];
    viewImg.style.marginTop = -viewTop * mul + 'px';
    viewImg.style.marginLeft = -viewLeft * mul + 'px';
    viewContent.style.display = 'block';
}

// 初始化图片
function setImage(src) {
    var img = new Image();
    img.src = src;
    imgW = img.width;
    imgH = img.height;
    // 将图片按比例放大或缩小以便内容区包含图片
    if (imgW > imgH) {
        imgW = contentWidth;
        imgH = imgH / imgW * contentWidth;
    } else {
        imgH = contentWidth;
        imgW = imgW / imgH * contentWidth;
    }
    imgCover.innerHTML = "<img src=" + src + " width=" + imgW + " height=" + imgH + "></img>";
    viewContent.innerHTML = "<img src=" + src + " width=" + imgW * mul + " height=" + imgH * mul + "></img>";
}
function init() {
    initMoveBox();
    bindEvent();
    window.onload = function () {
        imgList.getElementsByTagName('img')[0].click();
    }
    
}

init();